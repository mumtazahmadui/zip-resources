import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SummaryPipe } from './pipes/SummaryPipe';

//component
import { DashboardComponent } from './dashboard/dashboard.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { ManageNodesComponent } from './dashboard/nodes/manage-nodes/manage-nodes.component';

import { SupportModalComponent } from './common/support-modal/support-modal.component';
import { SupportCreateTicketComponent } from './common/support-create-ticket/support-create-ticket.component';
import { PlanPriceModalComponent } from './common/plan-price-modal/plan-price-modal.component';
import { PlanPriceTableComponent } from './common/plan-price-table/plan-price-table.component';

import { NodesApiService } from './services/nodes-api.service';
import { CreateNodeComponent } from './dashboard/nodes/create-node/create-node.component';
import  { TokenInterceptors } from './services/token-interceptor'; 
import { SearchFilterPipe } from './pipes/search-filter.pipe';
import { SortFilterPipe } from './pipes/sort-filter.pipe';
import { BackupComponent } from './dashboard/nodes/backup/backup.component';
import { NodeListComponent } from './dashboard/nodes/create-node/node-list/node-list.component';
import { RedeemComponent } from './common/redeem/redeem.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    SummaryPipe,
    SidebarComponent,
    HeaderComponent,
    FooterComponent,
    ManageNodesComponent,
    SupportModalComponent,
    SupportCreateTicketComponent,
    PlanPriceModalComponent,
    PlanPriceTableComponent,
    CreateNodeComponent,
    SearchFilterPipe,
    SortFilterPipe,
    BackupComponent,
    NodeListComponent,
    RedeemComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgbModule
  ],
  providers: [ NodesApiService, SearchFilterPipe, SortFilterPipe ,  { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptors, multi: true }, ],
  entryComponents: [ SupportModalComponent, PlanPriceModalComponent, RedeemComponent],
  bootstrap: [AppComponent]
})
export class AppModule {
}
