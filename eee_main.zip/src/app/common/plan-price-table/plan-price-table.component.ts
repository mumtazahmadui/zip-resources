import { Component, OnInit } from '@angular/core';
import { trigger, style, query, stagger, transition, animate } from '@angular/animations';


@Component({
  selector: 'plan-price-table',
  templateUrl: './plan-price-table.component.html',
  styleUrls: ['./plan-price-table.component.scss'],
  animations: [
    trigger('sliderAnimation', [
        transition('* => *', [
                query('.col', style({ opacity: 0, transform: 'translateX(-40px)' }), {optional: true}),
                query('.col', stagger('500ms', [
                animate('800ms 1.2s ease-out', style({ opacity: 1, transform: 'translateX(0)' })),
            ])),
            query('.col', [
            animate(1000, style('*'))
            ])
        ])
    ]),
]
})
export class PlanPriceTableComponent implements OnInit {
  state = 'off';
  selectedTabId = 'seriesA';

  colHead = ['Name', 'Price', 'VCPU', 'OS', 'Dedicated RAM', 'Disk Space'];

  colDetail = [
    { name : 'B.1GB', price:'₹261/mo | ₹0.35/hour',vcpu:'1', os:'CentOS / Debian / Ubuntu',dedicated:'2 GB', diskSpace:'10 GB SSD'},
    { name : 'BA.1GB', price:'₹261/mo | ₹0.35/hour',vcpu:'1', os:'CentOS / Debian / Ubuntu',dedicated:'2 GB', diskSpace:'10 GB SSD'},
    { name : 'BA.1GB', price:'₹261/mo | ₹0.35/hour',vcpu:'1', os:'CentOS / Debian / Ubuntu',dedicated:'2 GB', diskSpace:'10 GB SSD'}
  ];

  constructor() { }

  toggleState() {
      this.state = this.state === 'off' ? 'on' : 'off';
    }

  ngOnInit() {
  }

}

