export class SupportFields {
    constructor(
        public type = '',
        public subject = '',
        public message = '',
    ) { }
}