import { Component, Input } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SupportCreateTicketComponent } from '../support-create-ticket/support-create-ticket.component'

@Component({
  selector: 'app-support-modal',
  templateUrl: './support-modal.component.html',
  styleUrls: ['./support-modal.component.scss']
})
export class SupportModalComponent {

  @Input() name;

  constructor(public activeModal: NgbActiveModal) {}

}