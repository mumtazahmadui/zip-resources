import { Component, OnInit, Input, OnChanges } from '@angular/core';

import { NodesApiService } from '../../../../services/nodes-api.service';
import { SearchFilterPipe } from '../../../../pipes/search-filter.pipe';
import { SortFilterPipe } from '../../../../pipes/sort-filter.pipe';


interface IFields {
  ram: number;
  name?: string;
  minimum_billing?: any;
  type_name?: string;
  id: string;
  type: string;
  cpu: number;
}

@Component({
  selector: 'node-list',
  templateUrl: './node-list.component.html',
  styleUrls: ['./node-list.component.scss']
})
export class NodeListComponent implements OnInit, OnChanges {
  public loading = true;

  @Input() selectType;
  @Input() displayFamily;

  filterKeys: any;
  filterKeysName:any;
  displayItem: any;
  visibleList;
  sorkKey: string;
  isAsc: boolean;
  TotalCount: number;
  count: number;
  apiData: any;
  //model for reset
  selectVcpu: string;
  selectFamily: string;
  selectRam: string;
  storage:string;
  selectStorage:string;
  //ram and cpu
  rams: any;
  cpuPlans: any;
  isDisplay:boolean = false;
  displayGup:boolean = false;

  //Gen
  seriesFamily: string[] = ["Compute Intensive", "Memory Intensive", "Storage Intensive", "Smart Dedicated and GPU", "Smart Appliances", "Control Panels"];
  storageAll: string[] = ["10", "20", "30"];

  constructor(private searchFilter: SearchFilterPipe, private sortFilter: SortFilterPipe, private nodesApi: NodesApiService) {
  
  }

  page: number = 1;
  itemsPerPage: number = 10;

  ngOnInit() {
    this.sorkKey = "name";
    this.filterKeysName = { family: '', storage: '', ram: '', cpu: '' };
    this.filterKeys = Object.assign({}, this.filterKeysName);
    //this.getListData();
  }
  filter() {
    this.visibleList = this.searchFilter.transform(this.apiData, this.filterKeys);
    this.count = this.visibleList.length;
  }

  sort(key: string) {
    this.isAsc = !this.isAsc
    this.sorkKey = key;
    this.visibleList = this.sortFilter.transform(this.visibleList, this.sorkKey, this.isAsc);
  }

  getListData() {
    if (!this.selectType) {
      this.selectType = 'Ubuntu-14.04';
    }
    this.nodesApi.getProduction(this.selectType).subscribe((data) => {
      this.loading = false;
      this.apiData = data;
      //ram
      let ab = this.apiData.map(x => x.ram);
      this.rams = Array.from(new Set(ab));
      //cpu
      let cp = this.apiData.map(x => x.cpu);
      let cpSort = cp.sort((a, b) => a - b);
      this.cpuPlans = Array.from(new Set(cpSort));
      this.visibleList = this.apiData;
      this.count = this.apiData.length;
    },
      error => console.log("Error :" + error)
    )
  }

  ChangeStorage(series: string) {
    this.selectStorage = series;
  }

  ChangeFamily(family: string) {
    if (family == "0: undefined") {
      this.visibleList = this.apiData;
    } else {
      this.filterKeys.family = family;
      this.visibleList = this.searchFilter.transform(this.apiData, this.filterKeys);
      this.count = this.visibleList.length;
    }
  }

  ChangeCPU(cpu: string) {
    if (cpu == "0: undefined") {
      this.visibleList = this.apiData;
    } else {
      this.filterKeys.cpu = cpu;
      this.visibleList = this.searchFilter.transform(this.apiData, this.filterKeys);
      this.count = this.visibleList.length;
    }
  }

  ChangeRam(x:string) {
    //debugger
    if (x == "0: undefined") {
      this.visibleList = this.apiData;
    } else {
     // this.selectRam = x + " GiB RAM";
      this.filterKeys.ram = x;
      this.visibleList = this.searchFilter.transform(this.apiData, this.filterKeys);
      this.count = this.visibleList.length;
    }

  }

  edit(item) {
    this.displayItem = { name: item.type_name, plans: item.type, ram: item.ram, cpu: item.cpu };
    console.log(item)
  }

  resetAll() {
    this.filterKeys = this.filterKeysName;
    this.selectFamily = undefined;
    this.selectVcpu = undefined;
    this.selectRam = undefined;
    this.storage = "All SSD Storage";
    this.visibleList = this.apiData;
    console.log('I m here');
  }

  ngOnChanges() {
    this.loading = true;
    this.resetAll();
    if(!this.displayFamily) {
      this.isDisplay = true;
    } else if (this.displayFamily === 'ngb-tab-1'){
      debugger
      this.displayGup = true;
    } else {
      this.displayFamily !== 'ngb-tab-0' ? this.isDisplay = false : this.isDisplay = true;
    }
    
    setTimeout(() => {
      this.getListData();
    }, 1000);
  }
  
}