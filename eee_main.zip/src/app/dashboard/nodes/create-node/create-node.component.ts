import { Component, OnInit } from '@angular/core';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { SortFilterPipe } from '../../../pipes/sort-filter.pipe';
import { NodesApiService } from '../../../services/nodes-api.service';


@Component({
  selector: 'create-node',
  templateUrl: './create-node.component.html',
  styleUrls: ['./create-node.component.scss']
})
export class CreateNodeComponent implements OnInit {

  currentJustify = 'justified';
  
  commonText:string = "Select version";
  // Ubuntu
  ubuntuText: string = "Select version";
  ubuntuSeries: string[] = ["Ubuntu-18.04", "Ubuntu-16.04", "Ubuntu-14.04"];
  // Centos
  centosText: string = "Select version";
  centosSeries: string[] = ["CentOS-7.5", "CentOS-6.10"];
  // windows
  windowsText: string = "Select version";
  windowsSeries: string[] = ["Windows-2016", "Windows_2012_R2_STD"];
  // Dubian dubian
  dubianText: string = "Select version";
  dubianSeries: string[] = ["Debian-9", "Debian-8"];
  nodeDataset:any;

  cPanelText: string = "Select version";
  controlPanel:string[] = ["CentOS-7.5-cpanel"];

  pleskText: string = "Select version";
  pleskSeries:string[] = ["CentOS-Plesk"];

  webuzoText: string = "select Version";
  webuzoSeries:string[] = ["CentOS-7.5-Webuzo"];

  virtualText: string = "select Version";
  virtualSeries:string[] = ["CentOS-7.5-VirtualMin"];

  

  type:string;
  displayFamily: string;
  

  constructor(private nodesApi: NodesApiService, private searchFilter: SearchFilterPipe, private sortFilter: SortFilterPipe, ) { }

  ngOnInit() {
   // this.getPrData();'
    this.nodesApi.get().subscribe((nodeDataset: any[]) => {
        this.nodeDataset = nodeDataset;
        console.log(JSON.stringify(nodeDataset));
    });
  }

  reset(){
    this.ubuntuText = this.commonText;
    this.centosText = this.commonText;
    this.dubianText = this.commonText;
    this.windowsText= this.commonText;
    this.cPanelText = this.commonText;
    this.pleskText = this.commonText;
    this.webuzoText = this.commonText;
    this.virtualText = this.commonText;
  }


  // getPrData() {
  //   let type = 'Ubuntu-14.04';

  //   this.nodesApi.getProduction(type).subscribe((data) => {
  //     //this.loading = false;
  //     debugger;
  //     console.log(data);
  //   },
  //     error => console.log("Error :" + error)
  //   )
  // }


  filterByUbuntu(x) {
    this.reset();
    this.ubuntuText = x;
    this.type = x;
  }

  filterByCentos(x) {
    this.reset();
    this.centosText = x;
    this.type = x;
  }

  filterByWindows(x) {
    this.reset();
    this.windowsText = x;
    this.type = x;
  }
  filterByDubian(x) {
    this.reset();
    this.dubianText = x;
    this.type = x;
  }
  filterByCPanel(x) {
    this.reset();
    this.cPanelText = x;
    this.type = x;
  }
  filterByPlesk(x) {
    this.reset();
    this.pleskText = x;
    this.type = x;
  }
  filterByWebuzo(x) {
    this.reset();
    this.webuzoText = x;
    this.type = x;
  }
  filterByVirtual(x) {
    this.reset();
    this.virtualText = x;
    this.type = x;
  }

  getTabValue (evt: any) {
    //debugger;
    this.displayFamily = evt.nextId;
  }

 
}
