import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageNodesComponent } from './dashboard/nodes/manage-nodes/manage-nodes.component';
import { PlanPriceTableComponent } from './common/plan-price-table/plan-price-table.component'
import { CreateNodeComponent } from './dashboard/nodes/create-node/create-node.component';
import { BackupComponent } from './dashboard/nodes/backup/backup.component';

const routes: Routes = [
  {path: '', redirectTo: '/dashboard', pathMatch: 'full'},
  {path: 'dashboard', component: DashboardComponent},
  {path: 'vcn', component: ManageNodesComponent},
  {path: 'create', component: CreateNodeComponent},
  {path: 'plan', component: PlanPriceTableComponent},
  {path: 'table', component: BackupComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {
}
