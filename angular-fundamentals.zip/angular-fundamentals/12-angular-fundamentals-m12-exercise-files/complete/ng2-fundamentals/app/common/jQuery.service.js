"use strict";
var core_1 = require('@angular/core');
exports.JQ_TOKEN = new core_1.OpaqueToken('jQuery');
//# sourceMappingURL=jQuery.service.js.map