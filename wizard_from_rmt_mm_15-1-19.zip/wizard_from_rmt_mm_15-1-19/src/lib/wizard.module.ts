import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UiKitModule } from '@orrc-rfo-ui/ui-kit';
import { wizardRoutes } from './wizard.routing';
import { wizardGlobalComponents } from './components';
import { WizardComponent } from './containers/wizard.component';
import { StepEntitiesModule } from './containers/step-entities/step-entities.module';
import { StepDocumentsModule } from './containers/step-documents/step-documents.module';
import { StepReviewModule } from './containers/step-review/step-review.module';
import { StepProductsModule } from './containers/step-products/step-products.module';

@NgModule({
  imports: [
    UiKitModule,
    RouterModule.forChild(wizardRoutes),
    StepEntitiesModule,
    StepDocumentsModule,
    StepProductsModule,
    StepReviewModule,
  ],
  declarations: [
    WizardComponent,
    ...wizardGlobalComponents,
  ]
})
export class WizardModule {}
