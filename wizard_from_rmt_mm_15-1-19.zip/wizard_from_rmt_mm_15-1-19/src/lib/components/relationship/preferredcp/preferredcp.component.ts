import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
import { StepProductsService } from '../../../containers/step-products/step-products.service';
import { ApiClient } from '@orrc-rfo-ui/common';

@Component({
  selector: 'preferredcp',
  templateUrl: './preferredcp.component.html',
  styleUrls: ['./preferredcp.component.scss']
})
export class PreferredcpComponent implements OnInit {

  @Input() viewDialog: any = { relationshipListView: false };
  filteredRelationShipExistingList: any = [];
  existingFilter: FormGroup;
  relationShipExistingList: any = [];
  cpList: any = [];
  constructor(private service: StepProductsService,private api: ApiClient) { }

  ngOnInit() {
    this.prepareForms();
    this.subscribeToFilterChanges();
    this.mockData();
  }
  mockData() {


    this.relationShipExistingList = [
      {
        productName: 'commodities', cpRelation:
          [{
            cpinstitution: 'GoldMan Sachs', instituionSelect: false,
            nameLei: [
              { cpname: 'GoldMan Sachs International', cplei: 'ADALDKJKJKKAADA', selected: false },
              { cpname: 'GoldMan Sachs LP', cplei: 'AJDNAKJNDKANDAKND', selected: false }
            ]
          }, {
            cpinstitution: 'Barclays', instituionSelect: false,
            nameLei: [
              { cpname: 'Barclays International', cplei: 'MGHDJCVHVNCNH', selected: false },
              { cpname: 'Barclays LP', cplei: 'SBBFFSFSFJBJBBJBFJS', selected: false },
              { cpname: 'Barclays EMEA LP', cplei: 'SBBFFSFSFJBJBBJBFJS', selected: false }
            ]
          }
          ]
      }, {
        productName: 'Fix Spot', cpRelation:
          [{
            cpinstitution: 'GoldMan Sachs', instituionSelect: false,
            nameLei: [
              { cpname: 'GoldMan Sachs International', cplei: 'ADALDKJKJKKAADA', selected: false },
              { cpname: 'GoldMan Sachs LP', cplei: 'AJDNAKJNDKANDAKND', selected: false }
            ]
          }, {
            cpinstitution: 'Barclays', instituionSelect: false,
            nameLei: [
              { cpname: 'Barclays International', cplei: 'MGHDJCVHVNCNH', selected: false },
              { cpname: 'Barclays LP', cplei: 'SBBFFSFSFJBJBBJBFJS', selected: false },
              { cpname: 'Barclays EMEA LP', cplei: 'SBBFFSFSFJBJBBJBFJS', selected: false }
            ]
          }
          ]
      }
    ]
    this.cpList = [
      { label: 'Barclays', value: 'Barclays', selected: false },
      { label: 'CitiBank', value: 'CitiBank', selected: false },
      { label: 'GoldMan Sachs', value: 'GoldMan Sachs', selected: false },
      { label: 'Morgan Stanley', value: 'Morgan Stanley', selected: false },
      { label: 'Institution', value: 'Institution', selected: false }
  ];
  }

  private prepareForms() {
    this.existingFilter = new FormGroup({
      relationSearch: new FormControl(),
      institutionSearch: new FormControl(),
      entitesSearch: new FormControl(),
    });
  }
  private subscribeToFilterChanges() {
    this.filteredRelationShipExistingList = [...this.relationShipExistingList];
    this.existingFilter.valueChanges
      .pipe(debounceTime(500))
      .subscribe(changed => {
        console.log(changed);
        this.filterExisting(changed);
      })
  }
  private filterExisting(filters) {
    let items = [...this.relationShipExistingList];
    if (filters.relationSearch) {
      items = items.filter(item => {
        return item.productName.toUpperCase().indexOf(filters.relationSearch.toUpperCase()) != -1
      }
      )
    }

    if (filters.institutionSearch || filters.entitesSearch) {
      items.forEach(item => {
        item.cpRelation = filters.institutionSearch ?
          item.cpRelation.filter(it2 => it2.cpinstitution.toUpperCase().indexOf(filters.institutionSearch.toUpperCase())) : item.cpRelation;
        if (filters.entitesSearch) {
          item.cpRelation.forEach(it3 => {
            it3.nameLei = it3.nameLei.filter(it4 => it4.cpname.toUpperCase().indexOf(filters.entitesSearch.toUpperCase()))
          })
        }
      });
    }
    this.filteredRelationShipExistingList = items;
  }
}
