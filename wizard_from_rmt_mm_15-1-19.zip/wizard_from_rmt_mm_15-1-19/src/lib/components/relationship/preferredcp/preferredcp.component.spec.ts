import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferredcpComponent } from './preferredcp.component';

describe('PreferredcpComponent', () => {
  let component: PreferredcpComponent;
  let fixture: ComponentFixture<PreferredcpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreferredcpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreferredcpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
