import { CprelationshipComponent } from './cprelationship/cprelationship.component';
import { PreferredcpComponent } from './preferredcp/preferredcp.component';
import { PreferredproductComponent } from './preferredproduct/preferredproduct.component';
import { ProductrelationshipComponent } from './productrelationship/productrelationship.component';
import { RpentitiesComponent } from './rpentities/rpentities.component';

export const relationComponents = [
  CprelationshipComponent,
  PreferredcpComponent,
  PreferredproductComponent,
  ProductrelationshipComponent,
  RpentitiesComponent
];
