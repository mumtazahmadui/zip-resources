import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductrelationshipComponent } from './productrelationship.component';

describe('ProductrelationshipComponent', () => {
  let component: ProductrelationshipComponent;
  let fixture: ComponentFixture<ProductrelationshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductrelationshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductrelationshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
