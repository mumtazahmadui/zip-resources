import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { ApiClient } from '@orrc-rfo-ui/common';
import { StepProductsService } from '../../../containers/step-products/step-products.service';
import { flattenDepth, flattenDeep } from 'lodash';

@Component({
  selector: 'productrelationship',
  templateUrl: './productrelationship.component.html',
  styleUrls: ['./productrelationship.component.scss']
})
export class ProductrelationshipComponent implements OnInit {
  columnPr: any[];
  viewDialog: any = { productListView: false }
  viewPage: boolean = false;
  productNameList: any = [];
  productCodeList: any = [];
  dbProductList: any = [];
  selectProductFilters: any = {
    name: null,
    code: null
  }
  @Output() showDialog = new EventEmitter<any>();

  scrollHeight: any = '200px';

  selectProduct: any = [];
  loading: boolean = false;
  pageCount: any = { pdrow: 0, pdevent: 0 };
  constructor(private service: StepProductsService, private api: ApiClient) { }

  ngOnInit() {
    this.intializeProduct();
    this.productCodeFilter();
    this.productNameFilter();

    this.mockData();
  }
  intializeProduct() {
    this.api.fetch('product')
      .subscribe(res => this.selectProduct = res.data, err => console.log(err))
  }
  fullView(val) {
    this.showDialog.emit(val)
    if (this.viewPage) {
      this.scrollHeight = '200px';
    } else {
      this.scrollHeight = '400px';
    }
    this.viewPage = !this.viewPage;
  }
  clearProductFilter(dt) {
    dt.reset();
    this.api.fetch('product/')
      .subscribe(res => this.selectProduct = res.data, err => console.log(err))
    this.selectProductFilters = {
      name: null,
      code: null
    }
  }
  mockData() {
    this.columnPr = [
      { header: 'Product Name', field: 'name' },
      { header: 'Product Code', field: 'code' },
    ];
  }
  allSelectedProduct: boolean = true;
  productList: any = [];
  addProductView: boolean = false;
  selectAllProduct() {
    for (let st of this.selectProduct) {
      st.selected = this.allSelectedProduct;
    }
    this.allSelectedProduct = !this.allSelectedProduct;
    this.bindProduct();
  }
  blocked: boolean = false;
  productError: boolean = false;
  saveProduct() {
    this.productError = false;
    for (let da of this.productList) {
      if (!da.name || da.name.trim() == "") {
        da.nerror = true;
        this.productError = true;
      }
      if (!da.code || da.code.trim() == "") {
        da.cerror = true;
        this.productError = true;
      }
    }
    if (this.productList.length && !this.productError) {
      this.blocked = true;
      this.api.post('product', this.productList)
        .subscribe(res => {
          this.intializeProduct();
          this.blocked = false;
          this.addProductView = false;
        }, err => {
          this.blocked = false;
          console.log(err)
        }
        )
    }
  }
  addProduct() {
    this.productList.push({ name: '', code: '', selected: true, nerror: false });
  }
  removeProduct(val) {
    this.productList.splice(this.productList.indexOf(val), 1);
    if (this.productList.length == 0) {
      this.productError = false;
    }
  }
  productFilter(val, type) {
    if (type == 1) {

    } else if (type == 2) {
      this.api.fetch('product/?codeInBetween=' + val)
        .subscribe(res => this.selectProduct = res.data, err => console.log(err))
    }
  }

  productNameFilter() {
    var data = this.selectProductFilters.name;
    this.selectProduct.filter(da => {
      if (data.id == da.id) {
        da.selected = true;
      }
    }
    )
  }
  productCodeFilter() {
    var data = this.selectProductFilters.code;
    this.selectProduct.filter(da => {
      if (data.id == da.id) {
        da.selected = true;
      }
    }
    )
  }
  newProductbtn() {
    this.productList = [];
    this.productList = [{ name: '', code: '', selected: true, nerror: false }]
    this.addProductView = true;
  }
  bindProduct() {
    this.service.bindProductList(this.selectProduct.filter(da => da.selected));
  }
  applyProductRelation() {
    this.service.applyProductRelation();
  }

  loadDataOnScroll(event) {
    this.loading = true;
    if (event.first < this.pageCount.pdevent) {
      this.pageCount.pdrow += this.selectProduct.length - 50;
    } else {
      this.pageCount.pdrow += this.selectProduct.length
    }
    this.pageCount.pdevent = event.first;
    this.api.fetch('product?fromRow=' + this.pageCount.cprow + '&pageSize=50')
      .subscribe(res => {
        this.selectProduct = res.data
        this.loading = false;
      }
        , err => console.log(err))
  }
  applyProductListToEntity(productList) {
    debugger
    let idsOnly = flattenDeep(productList).map((it: any) => it.id)
    for (let pd of this.selectProduct) {
      pd.selected = idsOnly.indexOf(pd.id) != -1;
    }
    this.bindProduct();
    this.applyProductRelation();
  }
}
