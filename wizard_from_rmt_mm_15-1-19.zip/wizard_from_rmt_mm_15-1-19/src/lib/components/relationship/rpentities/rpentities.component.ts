import { Component, OnInit, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { StepProductsService } from '../../../containers/step-products/step-products.service';
import { ApiClient } from '@orrc-rfo-ui/common';

@Component({
  selector: 'rpentities',
  templateUrl: './rpentities.component.html',
  styleUrls: ['./rpentities.component.scss'],
})
export class RpentitiesComponent implements OnInit {
  column: any[];
  selectEntites: any[];
  allSelected: boolean = true;
  legalNameList: any[];
  identifierList: any[];
  LieList: any[];
  viewPage: boolean = false;
  selectEntitesFilters: any = {
    legalName: null,
    identifier: null,
    lei: null
  }
  @Output() showDialog = new EventEmitter<any>();
  scrollHeight: any = '200px';
  constructor(private service: StepProductsService, private api: ApiClient) { }

  ngOnInit() {
    this.mockData();
    this.selectEntites = this.service.getSelectedEntitesList();
  }
  clearEntites(dt) {
    dt.reset();
    this.selectEntitesFilters = {
      legalName: null,
      identifier: null,
      lei: null
    }
  }
  fullView(val) {
    this.showDialog.emit(val)
    if (this.viewPage) {
      this.scrollHeight = '200px';
    } else {
      this.scrollHeight = '400px';
    }
    this.viewPage = !this.viewPage;
  }
  mockData() {

    this.column = [
      { header: 'Entity Legal Name', field: 'legalName' },
      { header: 'Entity Identifier', field: 'identifier' },
      { header: 'Entity LEI', field: 'lei' },
      { header: 'Document', field: 'document' },
      { header: 'CP Entites', field: 'cpentities' },
      { header: 'Product Selected', field: 'product' }
    ];
    this.selectEntites =
      this.legalNameList = [
        { label: 'All', value: null },
        { label: 'Global Growth Fund Series1', value: 'Global Growth Fund Series1' },
        { label: 'Global Growth Fund Series2', value: 'Global Growth Fund Series2' },
        { label: 'Global Growth Fund Series3', value: 'Global Growth Fund Series3' },

      ];
    this.identifierList = [
      { label: 'All', value: null },
      { label: 'GC0091', value: 'GC0091' },
      { label: 'GC0092', value: 'GC0092' },
      { label: 'yeGC0093ar', value: 'yeGC0093ar' },

    ];
    this.LieList = [
      { label: 'All', value: null },
      { label: 'ASD', value: 'ASD' },
      { label: 'DFG', value: 'DFG' },
      { label: 'GFD', value: 'GFD' },

    ];
  }
  selectAll() {
    for (let st of this.selectEntites) {
      st.selected = this.allSelected;
    }
    this.allSelected = !this.allSelected;
  }
}
