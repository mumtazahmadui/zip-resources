import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpentitiesComponent } from './rpentities.component';

describe('RpentitiesComponent', () => {
  let component: RpentitiesComponent;
  let fixture: ComponentFixture<RpentitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpentitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpentitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
