import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CprelationshipComponent } from './cprelationship.component';

describe('CprelationshipComponent', () => {
  let component: CprelationshipComponent;
  let fixture: ComponentFixture<CprelationshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CprelationshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CprelationshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
