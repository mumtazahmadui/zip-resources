import { Component, OnInit, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { ApiClient } from '@orrc-rfo-ui/common';
import { StepProductsService } from '../../../containers/step-products/step-products.service';

@Component({
  selector: 'cprelationship',
  templateUrl: './cprelationship.component.html',
  styleUrls: ['./cprelationship.component.scss']
})
export class CprelationshipComponent implements OnInit {
  columnRl: any[];
  selectRelationList: any = [];
  cpLeiList: { label: string; value: string; }[];
  entityNameList: { label: string; value: string; }[];
  cpinstituionList: { label: string; value: string; }[];
  viewDialog: any = { relationshipListView: false }
  @Output() showDialog = new EventEmitter<any>();
  loading: boolean = false;
  scrollHeight: any = '200px';
  viewPage: boolean = false;
  pageCount: any = { cprow: 0, cpevent: 0 };
  selectCpFilters: any = {
    instituions: null,
    entityName: null,
    lei: null
  }
  constructor(private service: StepProductsService, private api: ApiClient) { }

  ngOnInit() {
    this.mockData()
    // this.api.fetch('counterparty-institution/')
    //   .subscribe(res => this.selectRelationList = res.data, err => console.log(err))
  }
  clearCpFilter(dt) {
    dt.reset();
    this.selectCpFilters = {
      instituions: null,
      entityName: null,
      lei: null
    }
  }
  fullView(val) {
    this.showDialog.emit(val)
    if (this.viewPage) {
      this.scrollHeight = '200px';
    } else {
      this.scrollHeight = '400px';
    }
    this.viewPage = !this.viewPage;
  }
  mockData() {
    this.columnRl = [
      { header: 'CP Instituions', field: 'cpinstitution' },
      { header: 'CP Entity Name', field: 'nameLei', subfield: 'cpname' },
      { header: 'CP Entity/LEI', field: 'nameLei', subfield: 'cplei' }

    ];
    this.cpinstituionList = [
      { label: 'All', value: null },
      { label: 'GoldMan Sachs', value: 'GoldMan Sachs' },
      { label: 'Barclays', value: 'Barclays' },
    ];
    this.entityNameList = [
      { label: 'All', value: null },
      { label: 'GoldMan Sachs International', value: 'GoldMan Sachs International' },
      { label: 'GoldMan Sachs LP', value: 'GoldMan Sachs LP' },

    ];
    this.cpLeiList = [
      { label: 'All', value: null },
      { label: 'ADALDKJKJKKAADA', value: 'ADALDKJKJKKAADA' },
      { label: 'ADALDKJKJKKADBKA', value: 'ADALDKJKJKKADBKA' },

    ];
  }
  bindCpRelation() {
    let data = [];
    data = this.selectRelationList.filter(da => da.companySelect)
    this.service.bindCpRelationList(data);
  }
  applyCpRelation(){
    this.service.applyCpRelation();
  }
  selectAllLegalName(data) {
    for (let et of data.entity) {
      et.selected = true;
    }
    this.bindCpRelation();
  }
  loadDataOnScroll(event) {
    this.loading = true;
    if (event.first < this.pageCount.cpevent) {
      this.pageCount.cprow += this.selectRelationList.length - 50;
    } else {
      this.pageCount.cprow += this.selectRelationList.length
    }
    this.pageCount.cpevent = event.first;
    this.api.fetch('counterparty-institution?fromRow=' + this.pageCount.cprow + '&pageSize=50')
      .subscribe(res => {
        this.selectRelationList = res.data
        this.loading = false;
      }, err => { this.loading = false; })
  }
}
