import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StepProductsService } from '../../../containers/step-products/step-products.service';
import { cloneDeep, unionBy } from 'lodash';
import { ApiClient } from '@orrc-rfo-ui/common';

@Component({
  selector: 'preferredproduct',
  templateUrl: './preferredproduct.component.html',
  styleUrls: ['./preferredproduct.component.scss']
})
export class PreferredproductComponent implements OnInit {
  @Input() viewDialog: any = { productListView: false };
  productListView: boolean = false;
  productView: boolean = false;
  @Output() applyProductListToEntity = new EventEmitter<any>();
  allSelectedProductcr: boolean = true;
  pdList: any = [];
  pdSelectedList: any = [];
  allSelectedAvailableProduct: boolean = true;
  availableProductList: any = [];
  newProductList: any = { name: null, selectedProduct: [] }
  productDataList: any = []
  addProductList: any = [];
  viewAddProduct: boolean = false;

  constructor(private service: StepProductsService, private api: ApiClient) { }

  ngOnInit() {
    this.mockData();
    this.api.fetch('product')
      .subscribe(res => this.availableProductList = res.data, err => console.log(err))
  }
  selectAllAvailableProduct() {
    for (let da of this.pdList) {
      da.selected = this.allSelectedAvailableProduct;
    }
    this.allSelectedAvailableProduct = !this.allSelectedAvailableProduct;
  }
  private mockData() {
    this.pdList = cloneDeep(this.service.getProductList());
    this.productDataList = [];
  }
  productExistSelection() {
    for (let da of this.pdList) {
      if (da.selected) {
        this.pdSelectedList.push(da);

      }
    }
    this.pdList = this.pdList.filter(item => {
      return !item.selected
    });
    this.allSelectedAvailableProduct = true;
  }
  onSelectProductRemove(data) {
    this.productDataList.selectedProduct.splice(this.productDataList.selectedProduct.indexOf(data), 1);
    this.addProductList.push(data);
  }
  onSelectProductRemoveAll() {
    for (let da of this.productDataList.selectedProduct) {
      this.addProductList.push(da);
    }
    this.productDataList.selectedProduct = [];

  }
  selectAllProductCr() {
    for (let pd of this.availableProductList) {
      this.newProductList.selectedProduct.push(pd);
    }
    this.availableProductList = [];
  }


  selectProduct(data) {
    this.newProductList.selectedProduct.push(data);
    this.availableProductList.splice(this.availableProductList.indexOf(data), 1);
  }
  removeSelectedProduct(data, flag) {
    if (flag) {
      for (let pd of this.newProductList.selectedProduct) {
        this.availableProductList.push(pd);
      }
      this.newProductList.selectedProduct = [];
    } else {
      this.newProductList.selectedProduct.splice(this.newProductList.selectedProduct.indexOf(data), 1);
      this.availableProductList.push(data);
    }
  }

  saveNewList() {
    this.service.saveNewList(cloneDeep(this.newProductList))
    this.viewDialog.productListView = false;
  }

  deleteProductList(data) {
    data.action = 'deleted'
    // this.pdList.splice(this.pdList.indexOf(data), 1);
  }
  showProducts(data) {
    this.productDataList = data;
    this.addproducts(true);
  }
  addproducts(flag) {
    this.addProductList = []
    if (this.productDataList) {
      let idsOnly = this.productDataList.selectedProduct.map(it => it.id)
      this.addProductList = cloneDeep(this.availableProductList);
      this.addProductList = this.addProductList.filter(da => {
        return idsOnly.indexOf(da.id) == -1
      })
      this.viewAddProduct = flag ? this.viewAddProduct : true;
    }
  }
  updateProduct() {
    for (let da of this.addProductList) {
      if (da.selected) {
        this.productDataList.selectedProduct.push(da);
      }
    }
    this.viewAddProduct = false;
  }
  applyProductList() {
    var data = [];
    for (let pd of this.pdList) {
      if (pd.selected) {
        data.unshift(pd.selectedProduct)
      }
    }
    this.applyProductListToEntity.emit(data);
    this.viewDialog.productListView = false;
  }
}
