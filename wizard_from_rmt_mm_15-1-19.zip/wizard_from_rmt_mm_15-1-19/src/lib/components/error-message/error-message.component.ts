import { Component, Input, OnInit } from '@angular/core';

export enum POSITIONS {
  TOP = 'top',
  BOTTOM = 'bottom',
  LEFT = 'left',
  RIGHT = 'right'
}

// TODO we have to implement all functionality in future - inproove styling, added style for left
@Component({
  selector: 'app-error-message',
  templateUrl: './error-message.component.html',
  styleUrls: ['./error-message.component.scss']
})
export class ErrorMessageComponent implements OnInit {

  @Input() errorMessagePosition: POSITIONS = POSITIONS.BOTTOM;

  public readonly positions = POSITIONS;

  constructor() {
  }

  ngOnInit() {
  }

}
