import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-toggle-checkbox',
  templateUrl: './toggle-checkbox.component.html',
  styleUrls: ['./toggle-checkbox.component.scss']
})

export class ToggleCheckboxComponent implements OnInit {


  @Input() leftLabel = '';
  @Input() rightLabel = '';
  @Output() change = new EventEmitter<boolean>();

  private checked = false;

  constructor() { }

  ngOnInit() {
  }

  onChange() {
    this.checked = !this.checked;
    this.change.emit(this.checked);
  }
}
