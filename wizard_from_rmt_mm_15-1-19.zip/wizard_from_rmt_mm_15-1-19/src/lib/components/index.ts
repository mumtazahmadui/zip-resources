import { HeaderBlockComponent } from './header-block/header-block.component';
import { MenuComponent } from './menu/menu.component';

export const wizardGlobalComponents = [
  HeaderBlockComponent,
  MenuComponent
];
