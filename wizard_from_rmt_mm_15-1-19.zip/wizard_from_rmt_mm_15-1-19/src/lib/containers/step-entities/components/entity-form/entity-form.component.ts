import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-entity-form',
  templateUrl: './entity-form.component.html',
  styleUrls: ['./entity-form.component.scss']
})
export class EntityFormComponent implements OnInit {

  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();

  public signatoryForm: FormGroup;
  public formSubmitAttempt = false;
  public loading = false;

  public errorMsgs = {
    required: 'This field is required.',
    pattern: 'Not allowed characters'
  };

  constructor(
    private readonly fb: FormBuilder,
  ) {
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }

  ngOnInit() {
    this.initForm();

  }

  public isFieldValid(fieldName: string) {
    const field = this.signatoryForm.get(fieldName);
    return !this.formSubmitAttempt || field.disabled || field.valid;
  }

  public getFormControlErrors(control: string): string[] {
    return Object.keys(this.signatoryForm.controls[control].errors || {});
  }

  public onSave(action = '') {
    this.formSubmitAttempt = true;
    if (this.signatoryForm.valid) {
      this.loading = true;
      const formValues = Object.assign({}, this.signatoryForm.getRawValue());
    }
  }

  private initForm() {
    this.signatoryForm = this.fb.group({
      legalName: ['', [
        Validators.required,
        Validators.pattern(new RegExp(/^a$/))
      ]],
      identifier: [{value: ''}, [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      lei: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      country: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      type: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      subType: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      aumnav: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      asOfDate: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      employeeLeverage: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      launchDate: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      sleeveAccount: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]],
      actingAs: [{value: undefined, disabled: true}, [
        Validators.required
      ]],
      institution: ['', [
        Validators.required,
        Validators.pattern(new RegExp(''))
      ]]
    });
  }

  changeToggle() {
    console.log('changeToggle');
  }


}
