import { Component, OnInit, TemplateRef, ViewEncapsulation } from '@angular/core';
import { BsModalRef, BsModalService, ModalModule } from 'ngx-bootstrap/modal';
import { EntityFormComponent } from '../entity-form/entity-form.component';
import { EntityFormPopupComponent } from '../entity-form-popup/entity-form-popup.component';

@Component({
  selector: 'app-create-entity-block',
  templateUrl: './create-entity-block.component.html',
  styleUrls: ['./create-entity-block.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CreateEntityBlockComponent implements OnInit {

  modalRef: BsModalRef;
  constructor(private modalService: BsModalService) {}
  template : {}

  openModal() {
    this.modalRef = this.modalService.show(EntityFormPopupComponent,{
      ignoreBackdropClick: true,
      class: 'upload-file-modal',
      initialState: {
        onUpload: (data) => {
          console.log(222);
        }
      }
    });
  }


  ngOnInit() {
  }

}
