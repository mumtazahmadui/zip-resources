import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';

@Component({
  selector: 'app-modal-header',
  templateUrl: './modal-header.component.html',
  styleUrls: ['./modal-header.component.scss']
})
export class ModalHeaderComponent implements OnInit {
  @Input() title: string;
  @Output() close = new EventEmitter();

  constructor(private readonly modalRef: BsModalRef) {
  }

  ngOnInit() {
  }

  onClose() {
    this.close.next();
    this.modalRef.hide();
  }
}
