import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-entity-block',
  templateUrl: './existing-entity-block.component.html',
  styleUrls: ['./existing-entity-block.component.scss']
})
export class ExistingEntityBlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
