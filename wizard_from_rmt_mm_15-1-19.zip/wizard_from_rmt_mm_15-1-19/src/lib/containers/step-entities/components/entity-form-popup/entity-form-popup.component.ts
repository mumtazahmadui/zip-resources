import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

@Component({
  selector: 'app-entity-form-popup',
  templateUrl: './entity-form-popup.component.html',
  styleUrls: ['./entity-form-popup.component.scss']
})
export class EntityFormPopupComponent implements OnInit {

  constructor(
    public modalRef: BsModalRef,
    public modalService: BsModalService,
  ) {}

  ngOnInit() {
  }

  close() {
    this.modalRef.hide();
  }
}
