import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selected-entities-block',
  templateUrl: './selected-entities-block.component.html',
  styleUrls: ['./selected-entities-block.component.scss']
})
export class SelectedEntitiesBlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
