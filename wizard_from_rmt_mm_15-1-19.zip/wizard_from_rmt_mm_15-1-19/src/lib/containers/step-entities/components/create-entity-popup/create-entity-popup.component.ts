import { Component, OnInit, TemplateRef, ViewEncapsulation } from '@angular/core';
import { BsModalRef, BsModalService, ModalModule } from 'ngx-bootstrap/modal';
import { EntityFormComponent } from '../entity-form/entity-form.component';

@Component({
  selector: 'app-create-entity-block',
  templateUrl: './create-entity-popup.component.html',
  styleUrls: ['./create-entity-popup.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CreateEntityPopupComponent implements OnInit {

  modalRef: BsModalRef;
  constructor(private modalService: BsModalService) {}

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template,{
      ignoreBackdropClick: true,
      keyboard: false,
      class: 'upload-file-modal',
      initialState: {
        onUpload: (data) => {
          console.log(222);
        }
      }
    });
  }


  ngOnInit() {
  }

}
