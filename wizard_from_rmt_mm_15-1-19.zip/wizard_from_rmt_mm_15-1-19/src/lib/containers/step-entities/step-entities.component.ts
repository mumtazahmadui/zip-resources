import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap';
import { MenuComponent } from '../../components/menu/menu.component';
import { CreateEntityBlockComponent } from './components/create-entity-block/create-entity-block.component';

@Component({
  selector: 'app-step-entities',
  templateUrl: './step-entities.component.html',
  styleUrls: ['./step-entities.component.scss']
})
export class StepEntitiesComponent implements OnInit {

  constructor(private bsModalService: BsModalService) {

  }

  ngOnInit() {

  }

}
