import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StepEntitiesComponent } from './step-entities.component';
import { StepEntitiesService } from './step-entities.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsModalRef, ModalModule } from 'ngx-bootstrap';
import { CreateEntityBlockComponent } from './components/create-entity-block/create-entity-block.component';
import { ExistingEntityBlockComponent } from './components/existing-entity-block/existing-entity-block.component';
import { EntityFormComponent } from './components/entity-form/entity-form.component';
import { ErrorMessageComponent } from '../../components/error-message/error-message.component';
import { EntityFormPopupComponent } from './components/entity-form-popup/entity-form-popup.component';
import { ModalHeaderComponent } from './components/modal-header/modal-header.component';
import { ToggleCheckboxComponent } from '../../components/toggle-checkbox/toggle-checkbox.component';


@NgModule({
  imports: [
    CommonModule,
    TabsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ModalModule.forRoot(),
  ],
  providers: [StepEntitiesService, BsModalRef],
  declarations: [
    StepEntitiesComponent,
    CreateEntityBlockComponent,
    ExistingEntityBlockComponent,
    EntityFormComponent,
    ErrorMessageComponent,
    EntityFormPopupComponent,
    ModalHeaderComponent,
    ToggleCheckboxComponent
  ],
  entryComponents: [
    EntityFormComponent,
    EntityFormPopupComponent
  ]
})
export class StepEntitiesModule {}
