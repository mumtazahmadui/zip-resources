import { NgModule } from '@angular/core';
import { StepProductsComponent } from './step-products.component';
import { StepProductsService } from './step-products.service';
import { UiKitModule } from '@orrc-rfo-ui/ui-kit';
import { relationComponents } from '../../components/relationship/relationIndex';


@NgModule({
  imports: [
    UiKitModule
  ],
  providers: [StepProductsService],
  declarations: [
    ...relationComponents,
    StepProductsComponent, 
  ]
})
export class StepProductsModule { }
