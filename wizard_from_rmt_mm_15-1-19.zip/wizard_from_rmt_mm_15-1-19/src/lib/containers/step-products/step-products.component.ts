import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { StepProductsService } from './step-products.service';
import { ApiClient } from '@orrc-rfo-ui/common';

@Component({
    selector: 'app-step-products',
    templateUrl: './step-products.component.html',
    styleUrls: ['./step-products.component.scss']
})
export class StepProductsComponent implements OnInit {
    @Input() entites: any;
    entity: any = {};
    entityView: boolean = false;
    cpView: boolean = false;
    productView: boolean = false;
    ngOnInit(): void { }
    blocked: boolean = false;
    constructor(private service: StepProductsService, private api: ApiClient) { }
    showDialog(type) {
        if (type == 1) {
            this.entityView = !this.entityView;
        } else if (type == 2) {
            this.cpView = !this.cpView;
        } else if (type == 3) {
            this.productView = !this.productView;
        }
    }










}