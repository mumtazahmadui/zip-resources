import { Injectable } from '@angular/core';

@Injectable()
export class StepProductsService {
    private selectedproductList: any = [];
    private mockproductList: any = [];
    private selectedEntites: any = []
    private cpRelation: any = []
    constructor() {
        this.mockEntites();
    }

    bindProductList(data) {
        this.selectedproductList = data;
    }
    bindCpRelationList(data) {
        this.cpRelation = data;
    }

    getProductList() {
        return this.mockproductList;
    }
    getSelectedEntitesList() {
        return this.selectedEntites;
    }
    saveNewList(data) {
        this.mockproductList.push(data)
    }

    applyCpRelation() {
        for (let entity of this.selectedEntites) {
            if (entity.selected) {
                if (this.selectedproductList) {
                    for (let pd of this.selectedproductList) {
                        var obj = { productName: pd, cpRelation: this.cpRelation };
                        entity.productList.push(obj);
                    }
                    entity.product = entity.product * 1 + this.selectedproductList.length
                } else {
                    var obj2 = { productName: { name: "", id: 0, code: "" }, cpRelation: this.cpRelation };
                    entity.productList.push(obj2);
                }
                entity.cpentities = entity.cpentities * 1 + this.cpRelation.length
            }
        }
    }
    applyProductRelation() {
        for (let entity of this.selectedEntites) {
            if (entity.selected) {
                for (let pd of this.selectedproductList) {
                    var obj = { productName: pd, cpRelation: this.cpRelation };
                    entity.productList.push(obj);
                }
                entity.product = entity.product * 1 + this.selectedproductList.length
                if (this.cpRelation) {
                    entity.cpentities = entity.cpentities * 1 + this.cpRelation.length
                }
            }
        }
    }

    private mockEntites() {
        this.mockproductList = [{ "name": "one", "selectedProduct": [{ "id": 2, "name": "Credit Derivatives", "code": "Cdr", "selected": false }, { "id": 1, "name": "Commodities", "code": "Comm", "selected": false }] }, { "name": "Two", "selectedProduct": [{ "id": 4, "name": "Fixed Income", "code": "FI", "selected": false }, { "id": 3, "name": "Equity Derivatives", "code": "Edr", "selected": false }] }];
        this.selectedEntites = [
            {
                legalName: 'Global Growth Fund Seriess', identifier: 'GC0091', lei: 'ASD', document: '01',
                cpentities: '02', product: '03', selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            }, {
                legalName: 'Global Growth Fund Seriess1', identifier: 'GC0091', lei: 'ASD', document: '01',
                cpentities: '02', product: '03', selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            }, {
                legalName: 'Global Growth Fund Series1s', identifier: 'GC0091', lei: 'ASD', document: '01',
                cpentities: '02', product: '03', selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            }, {
                legalName: 'Global Growth Fund Seriesss1', identifier: 'GC0091', lei: 'ASD', document: '01',
                cpentities: '02', product: '03', selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            },
            {
                legalName: 'Global Growth Fund Series2', identifier: 'GC0092', lei: 'DFG', document: 20,
                cpentities: 30, product: 40, selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            },
            {
                legalName: 'Global Growth Fund Series3', identifier: 'yeGC0093ar', lei: 'GFD', document: 30,
                cpentities: 40, product: 50, selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            },
            {
                legalName: 'Global Growth Fund Series5', identifier: 'yeGC0093ar', lei: 'GFD', document: 30,
                cpentities: 40, product: 50, selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            },
            {
                legalName: 'Global Growth Fund Series6', identifier: 'yeGC0093ar', lei: 'GFD', document: 30,
                cpentities: 40, product: 50, selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            },
            {
                legalName: 'Global Growth Fund Series7', identifier: 'yeGC0093ar', lei: 'GFD', document: 30,
                cpentities: 40, product: 50, selected: false, productList: [
                    {
                        productName: { name: 'commodities', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }, {
                        productName: { name: 'Fix Spot', id: 0, code: "" }, cpRelation:
                            [{
                                companyName: 'GoldMan Sachs', instituionSelect: false,
                                entity: [
                                    { legalName: 'GoldMan Sachs International', leiName: 'ADALDKJKJKKAADA', selected: false },
                                    { legalName: 'GoldMan Sachs LP', leiName: 'AJDNAKJNDKANDAKND', selected: false }
                                ]
                            }, {
                                companyName: 'Barclays', instituionSelect: false,
                                entity: [
                                    { legalName: 'Barclays International', leiName: 'MGHDJCVHVNCNH', selected: false },
                                    { legalName: 'Barclays LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false },
                                    { legalName: 'Barclays EMEA LP', leiName: 'SBBFFSFSFJBJBBJBFJS', selected: false }
                                ]
                            }
                            ]
                    }
                ]
            },
        ];
    }


}

