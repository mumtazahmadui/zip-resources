import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step-review',
  templateUrl: './step-review.component.html',
  styleUrls: ['./step-review.component.scss']
})
export class StepReviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
