import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StepReviewComponent } from './step-review.component';
import { StepReviewService } from './step-review.service';


@NgModule({
  imports: [
    CommonModule,
  ],
  providers: [StepReviewService],
  declarations: [
    StepReviewComponent,
  ]
})
export class StepReviewModule {}
