import { NgModule } from '@angular/core';
import { StepDocumentsComponent } from './step-documents.component';
import { StepDocumentsService } from './step-documents.service';
import { UiKitModule } from '@orrc-rfo-ui/ui-kit';
import { dialogContainers } from './popup';




@NgModule({
  imports: [
    UiKitModule,
    dialogContainers,
  ],
  providers: [StepDocumentsService],
  declarations: [
    StepDocumentsComponent
  ],
})
export class StepDocumentsModule {}
