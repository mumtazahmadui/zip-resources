import { Injectable } from '@angular/core';
import { ApiClient } from '@orrc-rfo-ui/common';

@Injectable()
export class StepDocumentsService {
    constructor(private api:ApiClient) { }

    getDocument() {
        const payload = [19000000048264,2]
        return this.api.post('entity',payload);
    }

    getDoc() {
        //query param
        return this.api.post('doc?entityId=65000000140750', {});
    }

    getDistributiongroup() {
        return this.api.fetch('distributiongroup');
    }

    getCpinstitution() {
        return this.api.fetch('cpinstitution?companyType=ss');
    }
    getUsers() {
        return this.api.fetch('users');
    }

    // getDownload () {
    //     const fileId = '65000001221413'
    //     return this.api.fetch('downloadFile/' + fileId);
    // }
    // getBulkDownload () {
    //     //const fileIds = '65000001221413'
    //     return this.api.fetch('bulkDownloadFile?fileIds=65000001221413');
    // }

    saveEntity() {
        const payload = [{
            requestId: 1,
            entityId: 65000000140750,
            docId: 65000000501524,
            deleted: 0,
            modifiedBy: 2
        }]
        return this.api.post('entitydoc', payload);
    }
}

