import { Component, OnInit, Input, ComponentFactoryResolver } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

import { FileUploadComponent } from './popup/file-upload/file-upload.component';
import { BulkUploadComponent } from './popup/bulk-upload/bulk-upload.component';
import { PermissionComponent } from './popup/permission/permission.component';

// Service
import { StepDocumentsService } from './step-documents.service';


/** TODO:
 * - Remove Mock Data
 * - downloadFile remove from html
 * - downloadBulk remove from html

 * */

//
const BsModalRefConfig = {
  ignoreBackdropClick: true,
  keyboard: false,
}

const BsModalRefLgConfig = {
  ignoreBackdropClick: true,
  keyboard: false,
  class: 'modal-lg'
}

const columnHeader = [
  { header: 'Entity Legal Name', field: 'legalName' },
  { header: 'Entity Identifier', field: 'identifier' },
  { header: 'Entity LEI', field: 'lei' },
  { header: 'Entity-Existing/New', field: 'entity' },
  { header: 'Upload Document', field: 'document' },
  { header: '# of Documents', field: 'cpentities' }
]
//mock data
const expandRowMock = [
  {
    "entityId": "19000000048264",
    "legalName": "Test 2.4.0 Company",
    "leiName": "ASDWQEQERWERWERWERWE",
    "clientIdentifier": null,
    "docCount": "72",
    "existingEntity": "existing"
  },
  {
    "entityId": "19000000048265",
    "legalName": "SA VOA 1",
    "leiName": null,
    "clientIdentifier": "SA VOA 1",
    "docCount": null,
    "existingEntity":
      "existing"
  }
]
const x = {
  docid: '100010',
  documentType: 'Certificate of Incorporation',
  uploadDate: '17-Feb-2018',
  docExpireDate: '19-Feb-2018',
  uploadedBy: 'Michelle',
  permissionTo: '5',
  download: 'img',
  selected: false
}

//component

@Component({
  selector: 'app-step-documents',
  templateUrl: './step-documents.component.html',
  styleUrls: ['./step-documents.component.scss']
})
export class StepDocumentsComponent implements OnInit {
  @Input() entites: any;
  entity: any = {};
  column: any[];
  selectEntites: any[];
  selectEntitesList: any[];
  mockData: any[];

  productList: any[];
  allSelected: boolean = true;
  allSelectedChild: boolean = true;
  batchUploadPopup: BsModalRef;
  constructor(readonly modalService: BsModalService, private stepDocumentsService: StepDocumentsService, ) { }

  ngOnInit(): void {

    this.getDocument();
    this.saveEntity();
    // this.getDoc();
    this.column = columnHeader;
    this.mockData = expandRowMock;
  }


  public saveEntity() {
    debugger
    this.stepDocumentsService.saveEntity().subscribe((res) => {
      console.log('saving', res)
    })
  }
  public getDocument() {
    this.stepDocumentsService.getDocument().subscribe(
      (data) => {
        console.log("DATA Document ::: ", data.data.rows)
        this.selectEntites = data.data.rows;
      },
      (_error) => {
        this.selectEntites = this.mockData;
      }
    )
  }


  public expandRow(rowData, expnded) {
    this.stepDocumentsService.getDoc().subscribe(
      (data) => {
        this.productList = data.data.rows;

        if (rowData.hasOwnProperty("productList")) {
          rowData['productList'] = data.data.rows;

        } else {
          rowData['productList'] = [];
          rowData['productList'] = data.data.rows;

        }
      },
      (_error) => {


        if (rowData.hasOwnProperty("productList")) {
          rowData['productList'].push(x)
        } else {
          rowData['productList'] = [];
          rowData['productList'].push(x)
        }
      })
  }

  selectAll() {
    for (let st of this.selectEntites) {
      st.selected = this.allSelected;
    }
    this.allSelected = !this.allSelected;
  }

  selectAllChild() {
    for (let st of this.selectEntites) {
      for (var value in st.productList) {
        st.productList[value].selected = st.productList[value].selected ? false : true;
      }
    }
    this.allSelectedChild = !this.allSelectedChild;
  }

  openUploadModal(rowData) {
    this.batchUploadPopup = this.modalService.show(FileUploadComponent, BsModalRefConfig);
    this.batchUploadPopup.content = rowData;
  }
  openBulkUploadModal() {
    this.batchUploadPopup = this.modalService.show(BulkUploadComponent, BsModalRefLgConfig);
  }
  openPermissionModal() {
    this.batchUploadPopup = this.modalService.show(PermissionComponent, BsModalRefLgConfig);
  }
}

  


// user later//
/*
public getDownload(item) {
  debugger
  console.log("Item :", item)
  this.stepDocumentsService.getDownload().subscribe((data) => {

    console.log('download data: ', data);
    const html: any = data;
    const newWindow = window.open();
    newWindow.document.write(html);

  })
}

  public getBulkDownload(){
  this.stepDocumentsService.getBulkDownload().subscribe((data) => {
    console.log('bk : ', data)
  })
}
     public getDocument() {
  this.stepDocumentsService.getDocument().subscribe((data) => {
    console.log("DATA Document ::: ", data.data.rows)
    this.selectEntites = data.data.rows;
  })
} 
public getDoc() {
    this.stepDocumentsService.getDoc().subscribe((data) => {
      console.log("Doc========================>",data);
    })
  }
*/