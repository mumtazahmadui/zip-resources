import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FileUploadComponent } from './file-upload.component';


@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [FileUploadComponent],
    exports: [FileUploadComponent],
    entryComponents: [FileUploadComponent]
})
export class FileUploadDialogPopupModule {
}