import { Component, OnInit, AfterViewInit, Input, ViewChild, ElementRef } from '@angular/core';
 import {BsModalRef } from 'ngx-bootstrap/modal'; 

import { Options } from 'selenium-webdriver';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

declare var Dropzone: any;


@Component({
  selector: 'orrc-rfo-ui-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit, AfterViewInit {

  @Input() Options: any;
  @ViewChild('dropzone') drpzoneContainer: ElementRef;
  @ViewChild('filetemplate') fileTemplate: ElementRef;
  @ViewChild('previewbox') previewBox: ElementRef;

  instance;
  show = false;
  constructor(public bsModalRef: BsModalRef) { }

  ngOnInit() {
  }
  ngAfterViewInit(): void {
    setTimeout(() => {
      let template = this.fileTemplate.nativeElement.innerHTML;
      this.instance = new Dropzone(this.drpzoneContainer.nativeElement, {
        //url: "/SpringFileUpload/uploadMultipleFile",
        url: "/orrc-rfo-bs-web-api/api/uploadFile/",
        autoProcessQueue: false,
        // parallelChunkUploads:true,
        //paramName: 'file',
       // multiple: true,
       // uploadMultiple: true,
        previewsContainer: this.previewBox.nativeElement,
        createImageThumbnails: false,
        parallelUploads: 100,
        previewTemplate: template,
        thumbnail: function (file, dataUrl) {
          console.log('working here i am', file);
        },
        init: function () {
          this.on("addedfile", function (file) {
            console.log(this.files);
          });

        },
        params: function (file) {
          console.log("sending", file);
          return { name: file[0].name };
        }
      });
      this.show = true;


    }, 1000);
  }

  uploadFiles() {
    this.instance.processQueue();
  }
  removeFiles() {
    this.instance.removeAllFiles(true);
  }
}
