import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BulkUploadComponent } from './bulk-upload.component';
import { UiKitModule } from '@orrc-rfo-ui/ui-kit';


@NgModule({
    imports: [
        CommonModule,
        UiKitModule
    ],
    declarations: [BulkUploadComponent],
    exports: [BulkUploadComponent],
    entryComponents: [BulkUploadComponent]
})
export class BulkUploadDialogPopupModule {
}