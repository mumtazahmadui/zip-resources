import { FileUploadDialogPopupModule } from "./file-upload/file-upload.module";
import { BulkUploadDialogPopupModule } from "./bulk-upload/bulk-upload.module";
import { PermissionDialogPopupModule } from "./permission/permission.module";


export const dialogContainers = [
    FileUploadDialogPopupModule,
    BulkUploadDialogPopupModule,
    PermissionDialogPopupModule
];

