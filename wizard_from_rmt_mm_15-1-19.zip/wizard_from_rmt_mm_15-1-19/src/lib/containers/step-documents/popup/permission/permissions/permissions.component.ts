import { Component, OnInit } from '@angular/core';
import { StepDocumentsService } from '../../../step-documents.service';

@Component({
  selector: 'tab-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.scss']
})
export class PermissionsComponent implements OnInit {
  public loading = true;
  public cpuInstitution:any = [];
  cpfilter: any = { companyname: '' };

  public distributionGroupList:any = [];
  dbFilter:any = {groupName : ''};

  public users:any = [];
  usersFilter:any = {email : ''}

  public teamList:any = [];
  tlFliter:any = '';
  constructor(private stepDocumentsService:StepDocumentsService) { }

  ngOnInit() {
    this.getCpuInstitution();
    this.getDistributiongroup();
  }

  getCpuInstitution(){
    this.stepDocumentsService.getCpinstitution().subscribe((data) => {
      this.loading = false;
      this.cpuInstitution = data.data.rows;

    })
  }

  public getDistributiongroup() {
    this.stepDocumentsService.getDistributiongroup().subscribe((data) => {
      this.distributionGroupList = data.data.distributionGroupList;
    })
  }

  public show(e: any, i: number) {
    const marked = e.target.checked;

    if (marked == true) {
      const usersData = this.distributionGroupList[i]['users'];
      const teamData = this.distributionGroupList[i]['teamList'];
      for (let value of usersData) {
        this.addUser(value);
      }
      for (let value of teamData) {
        this.addTeam(value);
      }
    }

    if (marked == false) {
      const usersData = this.distributionGroupList[i]['users'];
      const teamData = this.distributionGroupList[i]['teamList'];
      for (let value of usersData) {
        this.removeUser(value)
      }
      for (let value of teamData) {
        this.removeTeam(value)
      }
    }
  }

  public addUser(user: any) {
    const x = this.users.indexOf(user);
    if (x === -1) {
      this.users.unshift(user);
    }
  }
  public addTeam(team: any) {
    const x = this.teamList.indexOf(team);
    if (x === -1) {
      this.teamList.unshift(team);
    }
  }

  public removeUser(user: any) {
    const m = this.users.indexOf(user);
    if (m !== 1) {
      this.users.splice(m, 1);
    }
  }
  public removeTeam(team: any) {
    const m = this.teamList.indexOf(team);
    if (m !== 1) {
      this.teamList.splice(m, 1);
    }
  }

}
