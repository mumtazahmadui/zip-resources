import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PermissionComponent } from './permission.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { DistributionComponent } from './distribution/distribution.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
    imports: [
        CommonModule,
        FilterPipeModule,
        FormsModule,
        ReactiveFormsModule,
        TabsModule.forRoot(),
    ],
    declarations: [PermissionComponent, PermissionsComponent, DistributionComponent],
    exports: [PermissionComponent],
    entryComponents: [PermissionComponent]
})
export class PermissionDialogPopupModule {
}