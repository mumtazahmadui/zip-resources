import { Component, OnInit } from '@angular/core';
import { StepDocumentsService } from '../../../step-documents.service';

@Component({
  selector: 'tab-distribution',
  templateUrl: './distribution.component.html',
  styleUrls: ['./distribution.component.scss']
})
export class DistributionComponent implements OnInit {
  public users:any= [];
  usersFilter: any = { firstName: '' };
  public teamMember:any=[];
  public totalUsers:any = []
  public loading = true;

  constructor(private stepDocumentsService:StepDocumentsService) { }

  ngOnInit() {
    this.getUsers();
  }

  public getUsers() {
    this.stepDocumentsService.getUsers().subscribe((data) => {
      const totalUser = data.data;
      this.totalUsers = totalUser;
      this.users = totalUser;
      this.loading = false;
    });
  }

  public addTeamMember(user: {}) {
    // Add TeamMember
    const x = this.teamMember.indexOf(user);
    if (x === -1) {
      this.teamMember.unshift(user);
    }
    // Remove From User..
    const m = this.users.indexOf(user);
    if (m !== -1) {
      this.users.splice(m, 1);
    }
  }

  public removeTeamMember(user: {}) {
    // Revert User..
    const x = this.users.indexOf(user);
    if (x === -1) {
      this.users.unshift(user);
    }
    // Remove From TeamMember..
    const m = this.teamMember.indexOf(user);
    if (m !== 1) {
      this.teamMember.splice(m, 1);
    }
  }

  public selectAll() {
    if (!this.totalUsers.length) return;
    this.teamMember = this.totalUsers;
    this.users = [];
  }

  public removeAll() {
    if (!this.totalUsers.length) return;
    this.users = this.totalUsers;
    this.teamMember = [];
  }

}
