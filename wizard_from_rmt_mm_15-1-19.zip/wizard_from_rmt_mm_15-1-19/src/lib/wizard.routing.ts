import { Routes } from '@angular/router';
import { StepEntitiesComponent } from './containers/step-entities/step-entities.component';
import { WizardComponent } from './containers/wizard.component';
import { StepDocumentsComponent } from './containers/step-documents/step-documents.component';
import { StepReviewComponent } from './containers/step-review/step-review.component';
import { StepProductsComponent } from './containers/step-products/step-products.component';

export const wizardRoutes: Routes = [
  { path: '', component: WizardComponent, children: [
      { path: 'entities', component: StepEntitiesComponent },
      { path: 'documents', component: StepDocumentsComponent },
      { path: 'products', component: StepProductsComponent },
      { path: 'review', component: StepReviewComponent},
      {path: '', redirectTo: 'entities', pathMatch: 'full'}
    ] },
];
