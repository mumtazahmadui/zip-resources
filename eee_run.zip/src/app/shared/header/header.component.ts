import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { SupportModalComponent } from '../../common/support-modal/support-modal.component'
import { PlanPriceModalComponent } from '../../common/plan-price-modal/plan-price-modal.component'
import { RedeemComponent } from '../../common/redeem/redeem.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  pointsOfNotification:any[] = ["Notification Three", "Notification Two", "Test Notification", "Notification system"];

  constructor(private modalService: NgbModal) {}

  ngOnInit() { }

  openSupportModal() {
    const modalRef = this.modalService.open(SupportModalComponent, { size: 'lg' });
    modalRef.componentInstance.name = 'Support';
  }
  openPlanPrice(){
    const modalRef = this.modalService.open(PlanPriceModalComponent, { size: 'lg' });
    modalRef.componentInstance.name = 'Plan';
  }
  openCouponsModal(){
    const modalRef = this.modalService.open(RedeemComponent, { size: 'lg' });
    modalRef.componentInstance.name = 'Redeem';
  }

}
