import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  seq = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
  content = 'Some quick example text to build on the card title and make up the bulk of the card content.';

  constructor() {
  }

  ngOnInit() {
  }

}
