import { Component, OnInit, ElementRef } from '@angular/core';
import { cloneDeep } from 'lodash';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { SortFilterPipe } from '../../../pipes/sort-filter.pipe';
import { NodesApiService } from '../../../services/nodes-api.service';


@Component({
  selector: 'create-node',
  templateUrl: './create-node.component.html',
  styleUrls: ['./create-node.component.scss']
})
export class CreateNodeComponent implements OnInit {

  currentJustify = 'justified';
  
  //default text show
  commonText:string = "Select version";
  virtualUbuntuText =  cloneDeep(this.commonText);
  ubuntuText =  cloneDeep(this.commonText);
  centosText = cloneDeep(this.commonText);
  virtualCentosText = cloneDeep(this.commonText);
  windowsText = cloneDeep(this.commonText);
  dubianText = cloneDeep(this.commonText);
  GPUText = cloneDeep(this.commonText);
  cPanelText = cloneDeep(this.commonText);
  pleskText = cloneDeep(this.commonText);
  webuzoText = cloneDeep(this.commonText);
  virtualText = cloneDeep(this.commonText);

  virtualUbuntuSeries = [];
  virtualWindowSeries = [];
  virtualDubianSeries = [];  
  virtualCentosSeries = [];
  ubuntuSeries = [];
  centosSeries = []; 
  windowsSeries = []; // "Windows-2016", "Windows_2012_R2_STD"
  
  dubianSeries = []; // "Debian-9", "Debian-8"
  GPUSeries = [];
  controlPanel = [];
  pleskSeries = [];
  webuzoSeries = []; //"CentOS-7.5-Webuzo"
  virtualSeries = []; //"CentOS-7.5-VirtualMin"
  
  nodeDataset:any;
  type:string;
  displayFamily: string;
  

  constructor(
    private nodesApi: NodesApiService, 
    private searchFilter: SearchFilterPipe, 
    private sortFilter: SortFilterPipe, 
    private _host: ElementRef
    ) { }

  ngOnInit() {
   // this.getPrData();'
    this.nodesApi.get().subscribe((nodeDataset: any[]) => {
        this.nodeDataset = nodeDataset;
        let filterData = this.nodeDataset.data.map(x => x.os);

       // Array.from(new Set(filterData)).forEach(elm => { 
        filterData.forEach(elm => { 
         // debugger       
          let datas = JSON.stringify(elm.image);
          
         // Virtual 
          if(this.findWord(elm.image) === 'Distro') {
            if(datas.indexOf('Ubuntu') !== -1) {
              this.virtualUbuntuSeries.push(elm);
            }
             if(datas.indexOf('CentOS') !== -1) {
              this.virtualCentosSeries.push(elm);
            }
             if(datas.indexOf('Tally') !== -1) {
              console.log('Tally', elm)
            }
            if(datas.indexOf('Windows') !== -1) {
             this.virtualWindowSeries.push(elm);
            }
            if(datas.indexOf('Dubian') !== -1) {
              this.virtualDubianSeries.push(elm);
             }
          }
         
          // Smart Dedicated vs GPU
          if(this.findWord(elm.image) === 'Windows') {
            this.windowsSeries.push(elm);
          }
          if(this.findWord(elm.image) === 'Centos') {
            this.centosSeries.push(elm);
          }
          if(this.findWord(elm.image) === 'Ubuntu') {
            this.ubuntuSeries.push(elm);
          }
          if(this.findWord(elm.image) === 'Dubian') {
            this.dubianSeries.push(elm);
          }
          if(this.findWord(elm.image) === 'GPU') {
            this.GPUSeries.push(elm);
          }
          
          //Preinstall Control Panel
          if(this.findWord(elm.image) === 'cpanel') {
            this.controlPanel.push(elm);
          }
          if(this.findWord(elm.image) === 'PLESK') {
            this.pleskSeries.push(elm);
          }
          if(this.findWord(elm.image) === 'webuzo') {
            this.webuzoSeries.push(elm);
          }
          if(this.findWord(elm.image) === 'VirtualMin') {
            this.virtualSeries.push(elm);
          }
          
        });
        console.log('virtualUbuntuSeries', this.virtualUbuntuSeries)
        console.log('Filter Data: ', filterData);
    });
  }

  findWord(x){
    let n = x.split("-");
    return n[n.length - 1];
  }

  reset(){
    this.virtualUbuntuText = this.commonText;
    this.ubuntuText = this.commonText;
    this.centosText = this.commonText;
    this.dubianText = this.commonText;
    this.windowsText= this.commonText;
    this.cPanelText = this.commonText;
    this.pleskText = this.commonText;
    this.webuzoText = this.commonText;
    this.virtualText = this.commonText;
    this.virtualCentosText = this.commonText;
  }


  // getPrData() {
  //   let type = 'Ubuntu-14.04';

  //   this.nodesApi.getProduction(type).subscribe((data) => {
  //     //this.loading = false;
  //     debugger;
  //     console.log(data);
  //   },
  //     error => console.log("Error :" + error)
  //   )
  // }


  filterByUbuntu(x) {
    this.reset();
    this.ubuntuText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByVirtualUbuntu(x) {
    //const closetParent = this._host.nativeElement.closest('ul#displayView');
    this.reset();
    this.virtualUbuntuText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }

  filterByVirtualCentos(x) {
    this.reset();
    this.virtualCentosText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }

  filterByWindows(x) {
    this.reset();
    this.windowsText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByDubian(x) {
    this.reset();
    this.dubianText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByCentos(x) {
    this.reset();
    this.centosText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByGPU(x) {
    this.reset();
    this.GPUText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByCPanel(x) {
    this.reset();
    this.cPanelText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByPlesk(x) {
    this.reset();
    this.pleskText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByWebuzo(x) {
    this.reset();
    this.webuzoText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }
  filterByVirtual(x) {
    this.reset();
    this.virtualText = x.image;
    this.type = 'os=' + x.name + '&version=' + x.version;
  }

  getTabValue (evt: any) {
    //debugger;
    this.displayFamily = evt.nextId;
  }
}
