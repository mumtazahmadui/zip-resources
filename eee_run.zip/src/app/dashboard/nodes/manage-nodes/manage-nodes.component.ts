import { Component, OnInit } from '@angular/core';
import { NodesApiService } from '../../../services/nodes-api.service'

@Component({
  selector: 'manage-nodes',
  templateUrl: './manage-nodes.component.html',
  styleUrls: ['./manage-nodes.component.scss']
})
export class ManageNodesComponent implements OnInit {
  public loading = true;
  public nodes: any = [];

  constructor(private nodesApi: NodesApiService) { }
  ngOnInit() {
    this.getNodes();
    }

  getNodes() {
    this.nodesApi.getNodes().subscribe((data) => {
      //this.loading = false;
      this.nodes = data;
    },
    error => console.log("Error :" + error)
    )}
}
