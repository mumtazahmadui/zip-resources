import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

import { SupportFields } from './support-field';

@Component({
  selector: 'support-create-ticket',
  templateUrl: './support-create-ticket.component.html',
  styleUrls: ['./support-create-ticket.component.scss']
})
export class SupportCreateTicketComponent implements OnInit {
  //form Model
  supportTicket: FormGroup;
  //data model
  supportFields: SupportFields = new SupportFields();

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.supportTicket = this.fb.group({
        subject: ['', [Validators.required]],
        message: ['', [Validators.required]],
       
    });
  }

  @Input() name;

  save(){
    console.log('Saved: ' + JSON.stringify(this.supportTicket.value));
  }

}
