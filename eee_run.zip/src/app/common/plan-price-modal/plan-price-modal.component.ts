import { Component, Input } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SupportCreateTicketComponent } from '../support-create-ticket/support-create-ticket.component'

@Component({
  selector: 'app-plan-price-modal',
  templateUrl: './plan-price-modal.component.html',
  styleUrls: ['./plan-price-modal.component.scss']
})
export class PlanPriceModalComponent {

  @Input() name;

  constructor(public activeModal: NgbActiveModal) {}

}
