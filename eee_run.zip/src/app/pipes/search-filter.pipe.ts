import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'searchFilter' })

export class SearchFilterPipe implements PipeTransform {
  transform(items: any, filter: { [key: string]: any }): any {
      
    if (items) {
      return items.filter(item => {
        let match: boolean = true;
        for (var k in filter) {
          if (filter[k] && filter[k] != '') {
            if (typeof (item[k]) == "boolean") {
              let val: boolean = (filter[k] == "true");
              if (item[k] != val) {
                match = false;
              }
            }
            // else {
            //   if (item[k] && item[k] != "" && item[k].toString().toLowerCase().indexOf (filter[k].toString(). toLowerCase()) == -1)
            //     match = false;
            // }


          // } else if (typeof (item[k]) == "number") {
          //   if (item[k] && item[k] != "" && item[k]!==filter[k])
          //       match = false;
          // }
          // else {
          //   if (item[k] && item[k] != "" && item[k].toString().toLowerCase().indexOf (filter[k].toString().toLowerCase()) == -1)
          //     match = false;
          // }

            else {
             // debugger;
              if (item[k] && item[k] != "" && item[k].toString()!==filter[k].toString())
                match = false;
            }

          }
        }
        return match;
      });
    }
  }
}
// import { Pipe, PipeTransform } from '@angular/core';

// @Pipe({
//   name: 'searchFilter'
// })
// export class SearchFilterPipe implements PipeTransform {

//   transform(value: any, args?: any): any {
//     return null;
//   }

// }
