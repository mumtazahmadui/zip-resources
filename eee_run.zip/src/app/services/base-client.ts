import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from 'rxjs/operators';

/**
 * A Base client abstract service which will be extended by ApiClient and ServiceClient,
 * and both will override the getUrl function to return the prepared url
 */
export abstract class BaseClient {

    protected appConfig;

    constructor(protected http: HttpClient, protected type: string) { }

    //override it to get the url
    abstract getUrl(url);

    setAppConfig(config) {
        this.appConfig = config;
    }

    fetch(url): Observable<e2eResponse> {
        return this.http.get<e2eResponse>(this.getUrl(url))
            .pipe(catchError(this.handleError))
    }
    post(url, data = {}): Observable<e2eResponse> {
        return this.http.post<e2eResponse>(this.getUrl(url), data)
            .pipe(catchError(this.handleError))
    }
    put(url, data = {}): Observable<e2eResponse> {
      return this.http.put<e2eResponse>(this.getUrl(url), data)
        .pipe(catchError(this.handleError))
    }
    fetchWithParams(url, params: any): Observable<e2eResponse> {
        return this.http.get<e2eResponse>(this.getUrl(url), { params: params })
            .pipe(catchError(this.handleError))
    }

    getConfig() {
        return this.appConfig;
    }

    private handleError(err) {
        if (err instanceof HttpErrorResponse) {
            console.error('Api returned code', err.status, 'body was:', err.error);
            let error: e2eResponse = { statusCode: err.status, error: err.error };
            return throwError(error);
        }
    }
}

export class e2eResponse {
    data?: any;
    message?: string;
    error?: any;
    statusCode?: number;
}
