import { TokenInterceptor } from './token-interceptor';

describe('TokenInterceptor', () => {
  it('should create an instance', () => {
    expect(new TokenInterceptor()).toBeTruthy();
  });
});
