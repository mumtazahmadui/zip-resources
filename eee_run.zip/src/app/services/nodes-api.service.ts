import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from 'rxjs/operators';

import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class NodesApiService {
  
 // private baseUrl = 'http://a9191136.ngrok.io/api/my_account_virtualmachines';
  
  private APIURL = 'http://127.0.0.1:8000/cloud/os/list/';
  private envApiUrl = environment.apiUrl;
  private envApiKey = environment.apikey;

  private baseUrl = '/assets/data/data.json';
  private _urlState = '/assets/data/state.json';
  private _urlStateList = '/assets/data/GetDistList.json';
  private _urlWindow = '/assets/data/windows.json'; //change actual url

  private _nodeUrl = 'http://localhost:3000/data';

  _BaseUrl1:any;
  

  constructor(private http: HttpClient) { 
    this.setAuthToken();
  }

  getNodes() {
    return this.http.get<any[]>(`${this.baseUrl}`,{ headers: {'Content-Type': 'application/json'} });
  }//mn

  get() {
    return this.http.get<any[]>(`${this.envApiUrl}?apikey=${this.envApiKey}`);
  }

  post(postdata) {
    return this.http.post<any[]>(`${this.envApiUrl}?apikey=${this.envApiKey}`,postdata);
  }
  fetchall(param){
    return this.http.get<any[]>(`${this.envApiUrl}?apikey=${this.envApiKey}&${param}`);
  }

  setAuthToken(){
    localStorage.setItem('token', 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJGSjg2R2NGM2pUYk5MT2NvNE52WmtVQ0lVbWZZQ3FvcXRPUWVNZmJoTmxFIn0.eyJqdGkiOiIxOGU3NzZmNC03MTIyLTQ3ODUtODY5MC0yY2U2YzRkNjRhNWIiLCJleHAiOjE1ODg4MzkzNzcsIm5iZiI6MCwiaWF0IjoxNTU3MzAzMzc3LCJpc3MiOiJodHRwOi8vMTcyLjE2LjIxNS45NTo4MDgwL2F1dGgvcmVhbG1zL2FwaW1hbiIsImF1ZCI6ImFwaW1hbnVpIiwic3ViIjoiMzBjNDdjNWUtNDQ2Zi00MWFlLWFiMzAtMDYwNzFhNzcwODFlIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYXBpbWFudWkiLCJhdXRoX3RpbWUiOjAsInNlc3Npb25fc3RhdGUiOiI2YjQzZThiZi05ODA2LTQ3N2UtYWY2ZC01MmM1NzM0ODA4ZDkiLCJhY3IiOiIxIiwiY2xpZW50X3Nlc3Npb24iOiJiYmQxNmYzZS1hYjE2LTQzZTEtYmQxNC1hNTJiYWRkNjY4NWYiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsidW1hX2F1dGhvcml6YXRpb24iLCJhcGl1c2VyIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sIm5hbWUiOiJBYmhpIEphaW4iLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJhYmhpbmF2LmdhcmcrbmV3QGUyZW5ldHdvcmtzLmNvbSIsImdpdmVuX25hbWUiOiJBYmhpIiwiZmFtaWx5X25hbWUiOiJKYWluIiwiZW1haWwiOiJhYmhpbmF2LmdhcmcrbmV3QGUyZW5ldHdvcmtzLmNvbSJ9.BmvoSTRK29cT64Gqa9rK8F8lQljA5tD3-guTA96uectiUJAah0yTtaMBLljj5Ty9d85l1nqngB7sXRd3ixEVhwbGkWZ-jBaHEDwrRDoh_xS1F95kzuekubz-fCAX6YjkOxCAkt5GRiag4BZ205KJ5mLk02NXAJYIH454D-KebWg');
  }
  getAuthToken(){
   return localStorage.getItem('token');
  }

  // getData() {
  //   return this.http.get<any[]>(`${this.APIURL}`, { headers: { 'Content-Type': 'application/json' } });
  // }

  getState() {
    return this.http.get<any[]>(`${this._urlState}`, { headers: { 'Content-Type': 'application/json' } });
  }

  getStateList() {
    return this.http.get<any[]>(`${this._urlStateList}`, { headers: { 'Content-Type': 'application/json' } });
  }

  getWindow() {
    return this.http.get<any[]>(`${this._urlWindow}`, { headers: { 'Content-Type': 'application/json' } });
  }
 
  getProduction(type) {
    //alert(type + "base url" + this._BaseUrl1 );

    let osParam = "ubuntu&version=16.04";
    return this.fetchall(osParam);
    //this._BaseUrl1 = type !== ''? this._nodeUrl +"?type_name=" + type : this._nodeUrl;
    //alert(this._BaseUrl1);
    //return this.http.get<any[]>(`${this._BaseUrl1}`);
  }

  fetch(): Observable<e2eResponse> {
    return this.http.get<e2eResponse>(`${this.envApiUrl}?apikey=${this.envApiKey}`)
        .pipe(catchError(this.handleError))
    }

    private handleError(err) {
      if (err instanceof HttpErrorResponse) {
          console.error('Api returned code', err.status, 'body was:', err.error);
          let error: e2eResponse = { statusCode: err.status, error: err.error };
          return throwError(error);
      }
  }

}

export class e2eResponse {
  data?: any;
  message?: string;
  error?: any;
  statusCode?: number;
}
