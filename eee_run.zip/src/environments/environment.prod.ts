export const environment = {
  production: true,
  environmentName: 'production',
  apiUrl: 'http://localhost:8000'
};
